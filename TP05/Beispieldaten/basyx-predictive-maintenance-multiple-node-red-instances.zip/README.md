# Basyx - Capability Matching

## How to run the BaSyx containers
1. Extract the zip file on your device.
2. Open a terminal and navigate to the extracted folder.
3. Run the following command to start the BaSyx containers:
```
docker-compose up -d
```

## Access the BaSyx containers
- AAS Environment: [http://localhost:8086](http://localhost:8086)
- node-red-ehc10-35: [http://localhost:1880](http://localhost:1880)
- node-red-ehc10-50: [http://localhost:1881](http://localhost:1881)
- node-red-up150: [http://localhost:1882](http://localhost:1882)
